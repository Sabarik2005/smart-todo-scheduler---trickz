from flask import Flask, request, jsonify, render_template
from datetime import datetime
import sqlite3

app = Flask(__name__)

# Initialize SQLite database
def init_db():
    conn = sqlite3.connect('tasks.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS tasks
                 (id INTEGER PRIMARY KEY, name TEXT, deadline TEXT, dependencies TEXT, priority INTEGER, completed BOOLEAN)''')
    conn.commit()
    conn.close()

init_db()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/add_task', methods=['POST'])
def add_task():
    task = request.json
    conn = sqlite3.connect('tasks.db')
    c = conn.cursor()
    c.execute("INSERT INTO tasks (name, deadline, dependencies, priority, completed) VALUES (?, ?, ?, ?, ?)",
              (task['name'], task['deadline'], ','.join(task['dependencies']), task['priority'], False))
    conn.commit()
    conn.close()
    return get_all_tasks()

@app.route('/tasks', methods=['GET'])
def get_tasks():
    return get_all_tasks()

def get_all_tasks():
    conn = sqlite3.connect('tasks.db')
    c = conn.cursor()
    c.execute("SELECT * FROM tasks")
    tasks = c.fetchall()
    conn.close()
    return jsonify({'tasks': [{'id': task[0], 'name': task[1], 'deadline': task[2], 'dependencies': task[3].split(','), 'priority': task[4], 'completed': task[5]} for task in tasks]})

@app.route('/toggle_complete/<int:task_id>', methods=['PUT'])
def toggle_complete(task_id):
    conn = sqlite3.connect('tasks.db')
    c = conn.cursor()
    c.execute("UPDATE tasks SET completed = NOT completed WHERE id = ?", (task_id,))
    conn.commit()
    conn.close()
    return get_all_tasks()

@app.route('/edit_task/<int:task_id>', methods=['PUT'])
def edit_task(task_id):
    task = request.json
    conn = sqlite3.connect('tasks.db')
    c = conn.cursor()
    c.execute("UPDATE tasks SET name = ?, deadline = ?, dependencies = ?, priority = ? WHERE id = ?",
              (task['name'], task['deadline'], ','.join(task['dependencies']), task['priority'], task_id))
    conn.commit()
    conn.close()
    return get_all_tasks()

@app.route('/delete_task/<int:task_id>', methods=['DELETE'])
def delete_task(task_id):
    conn = sqlite3.connect('tasks.db')
    c = conn.cursor()
    c.execute("DELETE FROM tasks WHERE id = ?", (task_id,))
    conn.commit()
    conn.close()
    return get_all_tasks()

if __name__ == '__main__':
    app.run(debug=True)